﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HRMS.Entity;
using HRMS.Exception;
using HRMS.DAL;
using System.Data.SqlClient;
using System.Data;
using System.Text.RegularExpressions;

namespace HRMS.BL
{
    public class UserValidation
    {
        //Signup Code Validation 
        public static bool ValidateUser(Users newUser)
        {
            bool isValidUser = true;
            StringBuilder sbError = new StringBuilder();
            try
            {
                if (newUser.UserName == string.Empty )
                {
                    isValidUser = false;
                    sbError.Append("Please Enter UserName");
                }
                if(newUser.Password == string.Empty)
                {
                    isValidUser = false;
                    sbError.Append("\nPlease Enter Password");
                }


                if (newUser.FirstName == string.Empty)
                {
                    isValidUser = false;
                    sbError.Append("Please Enter First Name");
                }
                else if (!Regex.IsMatch(newUser.FirstName, "[A-Z][a-z]{2,}"))
                {
                    sbError.Append("First Name should start with Capital Alphabet, it should have minimum 3 characters and only alphabets\n");
                    isValidUser = false;
                }
                if (newUser.LastName == string.Empty)
                {
                    isValidUser = false;
                    sbError.Append("Please Enter Last Name");
                }
                else if (!Regex.IsMatch(newUser.LastName, "[A-Z][a-z]{2,}"))
                {
                    sbError.Append("Last Name should start with Capital Alphabet, it should have minimum 3 characters and only alphabets\n");
                    isValidUser = false;
                }
                if (!isValidUser)
                    throw new HRMSException(sbError.ToString());
            }
            catch (HRMSException ex)
            {
                throw ex;
            }

            return isValidUser;
        }

        //Add User Validation
        public static int AddClerk_BL(Users newUser)
        {
            int rowsAffected = 0;
            try
            {
                if (ValidateUser(newUser))
                {
                    rowsAffected = Users_DAL.AddClerk(newUser);
                }
                else
                    throw new HRMSException("\nPlease provide valid User Information");
            }
            catch (HRMSException ex) { throw ex; }
            catch (SqlException se) { throw se; }
            catch (SystemException ex) { throw ex; }
            return rowsAffected;

        }

        public static int UpdateClerk_BL(Users user)
        {
            int rowsAffected = 0;
            try
            {
                if (ValidateUser(user))
                {
                    rowsAffected = Users_DAL.AddClerk(user);
                }
                else
                    throw new HRMSException("\nPlease provide valid User Information");
            }
            catch (HRMSException ex) { throw ex; }
            catch (SqlException se) { throw se; }
            catch (SystemException ex) { throw ex; }
            return rowsAffected;

        }

        public static int DeleteClerk_BL(int userId)
        {
            int rowsAffected = 0;
            try
            {
              
                
                    rowsAffected = Users_DAL.DeleteClerk(userId);
              
            }
            catch (HRMSException ex) { throw ex; }
            catch (SqlException se) { throw se; }
            catch (SystemException ex) { throw ex; }
            return rowsAffected;

        }

        public static DataTable SearchUserById_BL(int userId)
        {
            DataTable user = null; 
            try
            {


                user = Users_DAL.SearchUserById(userId);

            }
            catch (HRMSException ex) { throw ex; }
            catch (SqlException se) { throw se; }
            catch (SystemException ex) { throw ex; }
            return user;

        }

        //Dispaly All Skill
        public static DataTable DisplayUsers_BL()
        {
            DataTable user = null;
            try
            {


                user = Users_DAL.DisplayUsers();



            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (HRMSException ex)
            {
                throw ex;
            }
            return user;
        }


        //Method to verify Login Credentials

    }
}

