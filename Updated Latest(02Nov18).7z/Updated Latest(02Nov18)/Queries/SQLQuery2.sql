select * from Group4.Employee


create proc Group4.usp_DisplayEmployeeDetails
as
Begin
select e.First_Name,e.Middle_Name,e.Last_Name,e.Birth_Date,e.Age,e.Gender,c.Status_Description,e.Religion,e.Citizenship,e.Mobile_No,e.Home_Phone_No,e.Address_,e.City,e.State_,e.Pincode,e.Country,p.Project_Name,s.Skill_Name,e.Educational_Background,cd.Email,lv.Level_Description,cd.Date_Hired,sp.Speciality_Name

from Group4.Employee e Join Group4.Civil_Status c on e.Civil_Status=c.Status_Id  join Group4.Project p  on e.Project_Id=p.Project_Id join Group4.Skill s on e.Skill_Id=s.Skill_Id join Group4.Capgemini_Details cd on e.Employee_Id=cd.Employee_Id join Group4.Level_ lv on cd.Level_Id=lv.Level_Id join Group4.Speciality sp on cd.Speciality=sp.Speciality_Id 
end