    ---/// <summary>
    ---/// Employee ID :161585
    ---/// Employee Name : Viraj Dere
    ---/// Description : Search Procedures
    ---/// Date of Creation : 10/19/2018
    ---/// </summary>




use Sep19CHN

--SEARCH PROCEDURES FOR HR CLERK
--SEARCH EMPLOYEE
CREATE PROC Group4.usp_SearchEmployee
(
	@Employee_Id		INT
)
AS
BEGIN
	SELECT * FROM Group4.Employee
	WHERE Employee_Id = @Employee_Id
END
GO

--SEARCH PROJECTS
CREATE PROC Group4.usp_SearchProject
(
	@Project_Id		INT
)
AS
BEGIN
	SELECT * FROM Group4.Project
	WHERE Project_Id = @Project_Id
END
GO

--SEARCH SKILLS
CREATE PROC Group4.usp_SearchSkills
(
	@Skill_Id		INT
)
AS
BEGIN
	SELECT * FROM Group4.Skill
	WHERE Skill_Id = @Skill_Id
END
GO

--SEARCH CATEGORIES
CREATE PROC Group4.usp_SearchCategories
(
	@Category_Id 	INT
)
AS
BEGIN
	SELECT * FROM Group4.Category
	WHERE Category_Id = @Category_Id
END
GO


--SEARCH PROCEDURES FOR ADMIN
--SEARCH USER
CREATE PROC Group4.usp_SearchUser
(
	@UserId 	INT
)
AS
BEGIN
	SELECT * FROM Group4.Users
	WHERE UserId = @UserId
END
GO

--SEARCH CIVILSTATUS
CREATE PROC Group4.usp_SearchCivilStatus
(
	@Status_Id	INT
)
AS
BEGIN
	SELECT * FROM Group4.Civil_Status
	WHERE Status_Id = @Status_Id
END
GO

--SEARCH LEVEL
CREATE PROC Group4.usp_SearchLevel
(
	@Level_Id	INT
)
AS
BEGIN
	SELECT * FROM Group4.Level_
	WHERE Level_Id = @Level_Id
END
GO