[‎10/‎27/‎2018 12:22 PM]  Dere, Viraj:  
Manish Can you send me Login Code
 
[‎10/‎27/‎2018 12:22 PM]  Rahangdale, Manish:  
yes wait
 
[‎10/‎27/‎2018 12:23 PM]  Dere, Viraj:  
Laal Message
 
[‎10/‎27/‎2018 12:23 PM]  Rahangdale, Manish:  
//Method to Validate HR Clerk/Manager Login From Database  
//Method to Validate HR Clerk/Manager Login From Database
        public static bool ValidateUser(string userId,string password,int roleId)
        {
            bool isValid = false;
            SqlDataReader empReader = null;
            try
            {
                //Creating command object
                SqlCommand empCommand = DataConnections.GenerateCommand();

              
                empCommand.CommandText = "Group4.usp_SearchUser";
                empCommand.Parameters.AddWithValue("@uName", userId);
                empCommand.Parameters.AddWithValue("@pass", password);
                empCommand.Parameters.AddWithValue("@rId", roleId);
                empCommand.Connection.Open();
                empReader = empCommand.ExecuteReader();
                if (empReader.HasRows)
                {
                    empReader.Read();
                    if(userId==empReader["UserName"].ToString() && password==empReader["Password_"].ToString())
                         isValid=true;
                }
                empReader.Close();
                empCommand.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return isValid;
        } 
 
[‎10/‎27/‎2018 12:26 PM]  Dere, Viraj:  
Send the procedure Group4.usp_SearchUser 
 
[‎10/‎27/‎2018 12:37 PM]  Dere, Viraj:  
Mr Manish how to send long message through skype
 
[‎10/‎27/‎2018 12:37 PM]  Dere, Viraj:  
Mr. Manish stop doing EF SOLO
 
