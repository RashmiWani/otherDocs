﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SalesmanEntityLibrary
{
    /// <summary>
    /// Employee ID : 161616
    /// Employee Name : Rashmi A. Wani
    /// Description : This is an Entity Class for Salesman details(refering to Question 1)
    /// Date of Modification : 8th Oct 2018
    /// </summary>
 
    public class SalesmanEntity
    {
        //Default constructor
        public SalesmanEntity()
        { }

        //Parameterized constructor
        public SalesmanEntity(int salesman_code, string salesman_name, string salesman_region, int salesman_target, int salesman_actsale)
        {
            this.salesman_code = salesman_code;
            this.salesman_name = salesman_name;
            this.salesman_region = salesman_region;
            this.salesman_target = salesman_target;
            this.salesman_actsale = salesman_actsale;
        }

        //Feilds of Entity class
        public int salesman_code;
        public string salesman_name;
        public string salesman_region;
        public int salesman_target;
        public int salesman_actsale;

        //Get or Set Salesman Code
        public int SalesmanCode { get { return salesman_code; } set { salesman_code = value; } }

        //Get or Set Salesman Name
        public string SalesmanName { get { return salesman_name; } set { salesman_name = value; } }

        //Get or Set Region
        public string SalesmanRegion { get { return salesman_region; } set { salesman_region = value; } }

        //Get or Set Salesman Target 
        public int SalesmanTarget { get { return salesman_target; } set { salesman_target = value; } }

        //Get or Set Salesman actual sales
        public int S_ActualSales { get { return salesman_actsale; } set { salesman_actsale = value; } }

     }
}

