﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;

namespace Reflection_SalesmanEntity
{
    /// <summary>
    /// Employee ID : 161616
    /// Employee Name : Rashmi A. Wani
    /// Description : This is a Reflection class to display details of Field, Properties and Constructors from Assembly
    /// Date of Modification : 8th Oct 2018
    /// </summary>
    class Program
    {
        static void Main(string[] args)
        {

            Assembly myAssembly = Assembly.LoadFrom("SalesmanEntityLibrary.dll");

            Type t = myAssembly.GetType("SalesmanEntityLibrary.SalesmanEntity");

            // Fetch details of Field in Assembly
            FieldInfo[] fldinfo = t.GetFields();
            Console.WriteLine("\n******************Number of Fields : " + fldinfo.Length);

            foreach (FieldInfo f in fldinfo)
            {
                Console.WriteLine("-------------------------");
                Console.WriteLine("Field Name : " + f.Name);
                Console.WriteLine("Field Type : " + f.FieldType);
                Console.WriteLine("Field Declaring Type : " + f.DeclaringType);
                Console.WriteLine("Field is notserialized : " + f.IsNotSerialized);
                Console.WriteLine("Field is static : " + f.IsStatic);
                Console.WriteLine("Field is private : " + f.IsPrivate);
                Console.WriteLine("-------------------------");
                Console.WriteLine();
            }

            // Fetch details of Properties in Assembly
            PropertyInfo[] props = t.GetProperties();
            Console.WriteLine("\n*******************Number of Properties : " + props.Length);

            foreach (PropertyInfo p in props)
            {
                Console.WriteLine("-------------------------");
                Console.WriteLine("Property Name : " + p.Name);
                Console.WriteLine("Can Read : " + p.CanRead);
                Console.WriteLine("Can Write : " + p.CanWrite);
                Console.WriteLine("Property Type : " + p.PropertyType);
                Console.WriteLine("Property: is special Name : " + p.IsSpecialName);
                Console.WriteLine("-------------------------");
                Console.WriteLine();
            }

            // Fetch details of Constructors in Assembly
            ConstructorInfo[] coninfo = t.GetConstructors();
            Console.WriteLine("\n*****************Number of Constuctors : " + coninfo.Length);

            foreach (ConstructorInfo c in coninfo)
            {
                Console.WriteLine("-------------------------");
                Console.WriteLine("is Constructor  : " + c.IsConstructor);
                Console.WriteLine("Constructor is static : " + c.IsStatic);
                Console.WriteLine("is final Constructor : " + c.IsFinal);
                Console.WriteLine("Constructor Reflected Type : " + c.ReflectedType);
                Console.WriteLine("is virtual constructor  : " + c.IsVirtual);
                Console.WriteLine("-------------------------");
                Console.WriteLine();
            }

            Console.ReadKey();
        }
    }
}
