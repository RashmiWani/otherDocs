﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using SJA.Entity;         //Reference for Salesman Entity  
using SJA.Exception;      //Reference for Salesman Exception

namespace SJA.DAL
{

    /// <summary>
    /// Employee ID : 161616
    /// Employee Name : Rashmi A. Wani
    /// Description : This class will provide CRUD operations for Salesman 
    /// Date of Modification : 8th Oct 2018
    /// </summary>
    public class SalesmanOperations
    {
        static List<Salesman> salesmanList = new List<Salesman>();

        //Method to add new Salesman
        public static bool AddSalesman(Salesman salman)
        {
            bool isAdded = false;

            try
            {
                //Adding Salesman in the list
                salesmanList.Add(salman);
                isAdded = true;
            }
            catch (SalesmanException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return isAdded;
        }

        //Method to search Salesman information
        public static Salesman SearchSalesman(int salCode)
        {
            Salesman sal = null;

            try
            {
                //Searching Salesman
                sal = salesmanList.Find(s => s.SalesmanCode == salCode);
            }
            catch (SalesmanException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return sal;
        }

        //Method to Serialize Salesman Data
        public static bool SerializeSalesman()
        {
            bool isSerialized = false;

            try
            {
                //Creating object of stream
                FileStream fs = new FileStream("SalesmanRecords.txt", FileMode.Create, FileAccess.Write);
                //Creating BinaryFormatter object
                BinaryFormatter bin = new BinaryFormatter();
                //Serializing Salesman data in stream
                bin.Serialize(fs, salesmanList);
                fs.Close();
                isSerialized = true;
            }
            catch (SalesmanException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return isSerialized;
        }


        //Method to deserialize Salesman details
        public static List<Salesman> DeserializeSalesman()
        {
            List<Salesman> salesmanList = null;

            try
            {
                //Creating object of stream
                FileStream fs = new FileStream("SalesmanRecords.txt", FileMode.Open, FileAccess.Read);
                //Creating BinaryFormatter object
                BinaryFormatter bin = new BinaryFormatter();
                //Deserializing Salesman data from stream
                salesmanList = (List<Salesman>)bin.Deserialize(fs);
                fs.Close();
            }
            catch (SalesmanException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return salesmanList;
        }
    }
}
