﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using SJA.Entity;        //Reference to Salesman Entity
using SJA.Exception;     //Reference to Salesman Exception
using SJA.BL;            //Reference to Business Layer

namespace SJA.PL
{
    /// <summary>
    /// Employee ID : 161616
    /// Employee Name : Rashmi A. Wani
    /// Description : Presentation Layer-with executable console application
    /// Date of Modification : 8th Oct 2018
    /// </summary>
    public class SaurabhJewelersApplication
    {
        //Method to add new Salesman Details
        public static void AddSalesman()
        {
            try
            {
                Salesman sal = new Salesman();
                Console.Write("Enter Salesman Code : ");
                sal.SalesmanCode = Convert.ToInt32(Console.ReadLine());

                Console.Write("Enter Salesman Name : ");
                sal.SalesmanName = Console.ReadLine();

                Console.Write("Enter Salesman Region : ");
                sal.SalesmanRegion = Console.ReadLine();

                Console.Write("Enter Salesman Target : ");
                sal.SalesmanTarget = Convert.ToInt32(Console.ReadLine());

                Console.Write("Enter Salesman Actual Sales value : ");
                sal.S_ActualSales = Convert.ToInt32(Console.ReadLine());

                bool isAdded = SalesmanValidations.AddSalesman(sal);

                if (isAdded)
                {
                    Console.WriteLine("Salesman details added successfully");
                }
                else
                    throw new SalesmanException("Salesman details not added");
            }
            catch (SalesmanException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        //Method to search Details of Salesman 
        public static void SearchSalesman()
        {
            try
            {
                int salCode;

                Console.Write("Enter Salesman Code for Search : ");
                salCode = Convert.ToInt32(Console.ReadLine());

                Salesman sal = SalesmanValidations.SearchSalesman(salCode);

                if (sal != null)
                {
                    Console.WriteLine("\nSalesman Code : " + sal.SalesmanCode);
                    Console.WriteLine("Salesman Name : " + sal.SalesmanName);
                    Console.WriteLine("Salesman Region : " + sal.SalesmanRegion);
                    Console.WriteLine("Salesman Target : " + sal.SalesmanTarget);
                    Console.WriteLine("Salesman Actual Sales : " + sal.S_ActualSales+"\n");
                }
                else
                    throw new SalesmanException("Salesman (" + salCode + ") not found");
            }
            catch (SalesmanException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        //Method to Serialize Details of Salesman 
        public static void SerializeSalesman()
        {
            try
            {
                bool isSerialized = SalesmanValidations.SerializeSalesman();

                if (isSerialized)
                    Console.WriteLine("Salesman Data is Serialized");
                else
                    throw new SalesmanException("Salesman Data is not Serialized");
            }
            catch (SalesmanException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        //Method to deserialize Details of Salesman 
        public static void DeserializeSalesman()
        {
            try
            {
                List<Salesman> salesmanList = SalesmanValidations.DeserializeSalesman();

                if (salesmanList != null || salesmanList.Count > 0)
                {
                    Console.WriteLine("------------------------------------------------------------------------------");
                    Console.WriteLine("Salesman Code \t Salesman Name \t Sales Region \t Sales Target \t Actual Sales");
                    Console.WriteLine("------------------------------------------------------------------------------");
                    foreach (Salesman sal in salesmanList)
                    {
                        Console.WriteLine(sal.SalesmanCode + "\t\t" + sal.SalesmanName + "\t\t" + sal.SalesmanRegion + "\t\t" + sal.SalesmanTarget + "\t\t" + sal.S_ActualSales);
                    }
                    Console.WriteLine("------------------------------------------------------------------------------");
                }
                else
                    throw new SalesmanException("Salesman Details not deserialized");
            }
            catch (SalesmanException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        //method to print menu
        public static void PrintMenu()
        {
            Console.WriteLine("------------------------");
            Console.WriteLine("1. Add Salesman");
            Console.WriteLine("2. Search Salesman");
            Console.WriteLine("3. Serialize Salesman");
            Console.WriteLine("4. Deseialize Salesman");
            Console.WriteLine("5. Exit");
            Console.WriteLine("-----------------------");
        }
        static void Main(string[] args)
        {
            try
            {
                int choice;
                Console.WriteLine("\n******   Saurabh Jewelers Salesman Application   *****\n");
                do
                {
                    PrintMenu();
                    Console.Write("Enter your choice : ");
                    choice = Convert.ToInt32(Console.ReadLine());

                    switch (choice)
                    {
                        case 1:
                            AddSalesman();
                            break;
                        case 2:
                            SearchSalesman();
                            break;
                        case 3:
                            SerializeSalesman();
                            break;
                        case 4:
                            DeserializeSalesman();
                            break;
                        case 5:
                            Environment.Exit(0);
                            break;
                        default:
                            Console.Write("Invalid Choice\n");
                            break;
                    }
                } while (choice != 5);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
            Console.ReadKey();
        }
    }
}
