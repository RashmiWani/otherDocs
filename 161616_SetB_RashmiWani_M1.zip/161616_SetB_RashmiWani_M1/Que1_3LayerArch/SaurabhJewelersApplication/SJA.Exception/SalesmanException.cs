﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SJA.Exception
{
    /// <summary>
    /// Employee ID : 161616
    /// Employee Name : Rashmi A. Wani
    /// Description : This is an Exception Class for Salesman 
    /// Date of Modification : 8th Oct 2018
    /// </summary>
    public class SalesmanException : ApplicationException
    {
        //Default Constructor
        public SalesmanException() : base()
        { }

        //Parameterized constructor with message parameter
        public SalesmanException(string message) : base(message)
        { }
    }
}
