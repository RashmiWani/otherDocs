﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WPF_DependencySample
{
    class ProductDetails
    {
        public List<Product> GetProduct()
        {
            Product prod = new Product { ProductName = "Pen", Category="Stationary"};
            return prod;
        }
        public Product GetNewProduct()
        {
            NewProduct prodnew = new NewProduct { ProductName = "Chair", ProductCategory = "Stationary" };
            return prodnew ;
        }
    }
}
