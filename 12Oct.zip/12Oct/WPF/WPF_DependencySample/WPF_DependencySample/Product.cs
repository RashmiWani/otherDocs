﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;


namespace WPF_DependencySample
{
    class Product
    {
        public string ProductName { get; set; }
        public string Category { get; set; }
    }
    public class NewProduct : DependencyObject
    {


        public string ProductName
        {
            get { return (string)GetValue(ProductNameProperty); }
            set { SetValue(ProductNameProperty, value); }
        }

        // Using a DependencyProperty as the backing store for ProductName.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty ProductNameProperty =
            DependencyProperty.Register("ProductName", typeof(string), typeof(NewProduct), new PropertyMetadata(0));



        public string ProductCategory
        {
            get { return (string)GetValue(ProductCategoryProperty); }
            set { SetValue(ProductCategoryProperty, value); }
        }

        // Using a DependencyProperty as the backing store for ProductCategory.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty ProductCategoryProperty =
            DependencyProperty.Register("ProductCategory", typeof(string), typeof(NewProduct), new PropertyMetadata(0));


    }
}
