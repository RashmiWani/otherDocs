﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Day2_ListBinding
{
    public class Product
    {
        public Product(string pro_id, string pro_Name, string pro_Price)
        {
            this.pro_id = pro_id;
            this.pro_Name = pro_Name;
            this.pro_Price = pro_Price;
          }
        public Product()
            : this("unknown", "unknown", "unknown")
        {
        }
        private string pro_id;
        public string ProductID
        {
            get { return pro_id; }
            set { pro_id = value; }
        }
        private string pro_Name;
        public string ProductName
        {
            get { return pro_Name; }
            set { pro_Name = value; }
        }
        private string pro_Price;
        public string ProductPrice
        {
            get { return pro_Price; }
            set { pro_Price = value; }
        }

        public override string ToString()
        {
            return pro_id + " " + pro_Name + " " + pro_Price;
        }
  
    }
}
