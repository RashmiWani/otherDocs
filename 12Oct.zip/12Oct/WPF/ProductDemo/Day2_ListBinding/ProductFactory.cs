﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Day2_ListBinding
{
    public class ProductFactory
    {
        private List<Product> books = new List<Product>();
        public ProductFactory()
        {
            books.Add(new Product("PRO1121", "Desktop", "2000"));
            books.Add(new Product("PRO1124", "Mouse", "2000"));
            books.Add(new Product("PRO1128", "Key-Board", "2000"));
            books.Add(new Product("PRO1144", "CPU", "2000"));
            books.Add(new Product("PRO1119", "Hard Disk", "2000"));
            books.Add(new Product());
        }
        public List<Product> GetBooks()
        {
            return books;
        }
    }
}
