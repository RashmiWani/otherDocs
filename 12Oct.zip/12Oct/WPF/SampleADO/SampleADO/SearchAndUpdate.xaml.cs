﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;


namespace SampleADO
{
    /// <summary>
    /// Interaction logic for SearchAndUpdate.xaml
    /// </summary>
    public partial class SearchAndUpdate : Window
    {
        public SearchAndUpdate()
        {
            InitializeComponent();
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            SqlConnection connObj = new SqlConnection(@"Data Source=ndamssql\sqlilearn;Initial Catalog=Sep19CHN;User ID=sqluser;Password=sqluser");
            SqlCommand searchCmd = new SqlCommand("Rashmi.usp_SearchEmployee", connObj);
            searchCmd.CommandType = CommandType.StoredProcedure;
            searchCmd.Parameters.AddWithValue("@eID", txt_EmpID.Text);

            SqlDataReader rdr = null;
            connObj.Open();
            rdr = searchCmd.ExecuteReader(CommandBehavior.CloseConnection);     //CommandBehavior.CloseConnection: to close connection automatically
            if (rdr.HasRows)
            {
                can_Data.Visibility = Visibility.Visible;

                txt_EmpName.Text = rdr["EmpName"].ToString();
                txt_Location.Text = rdr["EmpLocation"].ToString();
                txt_Phone.Text = rdr["EmpContact"].ToString();
            }
            else
                MessageBox.Show("No records found");
            rdr.Close();

        }
    }
}
