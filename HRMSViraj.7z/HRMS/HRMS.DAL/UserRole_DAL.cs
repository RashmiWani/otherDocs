﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HRMS.Entity;
using System.Data.SqlClient;
using System.Data;
namespace HRMS.DAL
{
    /// <summary>
    /// Employee ID :161585
    /// Employee Name : Viraj Dere
    /// Description : Handles UserRole(HR Clerk/Manager-Admin) Specific operations
    /// Date of Creation : 10/23/2018
    /// </summary>
    public class UserRole_DAL
    {
        
        

        
    }
}
