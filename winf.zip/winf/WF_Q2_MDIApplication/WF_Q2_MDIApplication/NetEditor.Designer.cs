﻿namespace WF_Q2_MDIApplication
{
    partial class NetEditor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip = new System.Windows.Forms.MenuStrip();
            this.menuStripDocument = new System.Windows.Forms.ToolStripMenuItem();
            this.menuDocNew = new System.Windows.Forms.ToolStripMenuItem();
            this.menuDocOpen = new System.Windows.Forms.ToolStripMenuItem();
            this.menuDocClose = new System.Windows.Forms.ToolStripMenuItem();
            this.menuDocSave = new System.Windows.Forms.ToolStripMenuItem();
            this.menuDocExit = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip
            // 
            this.menuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuStripDocument});
            this.menuStrip.Location = new System.Drawing.Point(0, 0);
            this.menuStrip.Name = "menuStrip";
            this.menuStrip.Size = new System.Drawing.Size(406, 24);
            this.menuStrip.TabIndex = 1;
            this.menuStrip.Text = "menuStrip1";
            // 
            // menuStripDocument
            // 
            this.menuStripDocument.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuDocNew,
            this.menuDocOpen,
            this.menuDocClose,
            this.menuDocSave,
            this.menuDocExit});
            this.menuStripDocument.Name = "menuStripDocument";
            this.menuStripDocument.Size = new System.Drawing.Size(75, 20);
            this.menuStripDocument.Text = "Document";
            // 
            // menuDocNew
            // 
            this.menuDocNew.Name = "menuDocNew";
            this.menuDocNew.Size = new System.Drawing.Size(152, 22);
            this.menuDocNew.Text = "New";
            this.menuDocNew.Click += new System.EventHandler(this.openToolStripMenuItem_Click);
            // 
            // menuDocOpen
            // 
            this.menuDocOpen.Name = "menuDocOpen";
            this.menuDocOpen.Size = new System.Drawing.Size(152, 22);
            this.menuDocOpen.Text = "Open";
            this.menuDocOpen.Click += new System.EventHandler(this.menuDocOpen_Click);
            // 
            // menuDocClose
            // 
            this.menuDocClose.Name = "menuDocClose";
            this.menuDocClose.Size = new System.Drawing.Size(152, 22);
            this.menuDocClose.Text = "Close";
            this.menuDocClose.Click += new System.EventHandler(this.closeToolStripMenuItem1_Click);
            // 
            // menuDocSave
            // 
            this.menuDocSave.Name = "menuDocSave";
            this.menuDocSave.Size = new System.Drawing.Size(152, 22);
            this.menuDocSave.Text = "Save";
            this.menuDocSave.Click += new System.EventHandler(this.menuDocSave_Click);
            // 
            // menuDocExit
            // 
            this.menuDocExit.Name = "menuDocExit";
            this.menuDocExit.Size = new System.Drawing.Size(152, 22);
            this.menuDocExit.Text = "Exit";
            this.menuDocExit.Click += new System.EventHandler(this.menuDocExit_Click);
            // 
            // NetEditor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(406, 372);
            this.Controls.Add(this.menuStrip);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip;
            this.Name = "NetEditor";
            this.Text = "Form1";
            this.menuStrip.ResumeLayout(false);
            this.menuStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip;
        private System.Windows.Forms.ToolStripMenuItem menuStripDocument;
        private System.Windows.Forms.ToolStripMenuItem menuDocNew;
        private System.Windows.Forms.ToolStripMenuItem menuDocOpen;
        private System.Windows.Forms.ToolStripMenuItem menuDocClose;
        private System.Windows.Forms.ToolStripMenuItem menuDocSave;
        private System.Windows.Forms.ToolStripMenuItem menuDocExit;
    }
}

