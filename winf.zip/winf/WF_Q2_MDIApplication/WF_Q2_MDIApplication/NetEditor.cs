﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace WF_Q2_MDIApplication
{
    public partial class NetEditor : Form
    {
        public NetEditor()
        {
            InitializeComponent();
        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            NetEditorChild nec = new NetEditorChild();
            nec.Text = "New Document"; nec.MdiParent = this;
            nec.Show();
        }

        private void closeToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            if (this.ActiveMdiChild != null)
                this.ActiveMdiChild.Close();
        }

        private void menuDocExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        public void menuDocOpen_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog1 = new OpenFileDialog();
            openFileDialog1.Filter = "Text Files|*.txt|XML Files|*.xml";
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                StreamReader sr = new StreamReader(File.OpenRead(openFileDialog1.FileName));
                NetEditorChild nec = new NetEditorChild();
                nec.Text = openFileDialog1.FileName;
                nec.textBox1.Text = sr.ReadToEnd();
                sr.Close();
                nec.MdiParent = this;
                nec.Show();
            }
        }


        private void menuDocSave_Click(object sender, EventArgs e)
        {
            NetEditorChild nec = new NetEditorChild();
            SaveFileDialog sv = new SaveFileDialog();
            if (sv.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                File.WriteAllText(sv.FileName, );
                //Stream s = File.Open(sv.FileName, FileMode.CreateNew);
                //StreamWriter sw = new StreamWriter(s);
                //    sw.Write(nec.textBox1.Text);
                //sw.Flush();

                //FileStream fs = new FileStream(sv.FileName, FileMode.CreateNew);
                //StreamWriter sw = new StreamWriter(fs);
                //sw.Write(nec.textBox1.Text);
              
                //fs.Close();
            }
        }
        //FileStream fs = new FileStream("Stream.txt", FileMode.Create, FileAccess.Write);
        //StreamWriter sw = new StreamWriter(fs);
        //sw.WriteLine(123456);
        //    sw.WriteLine(".NET Batch");
        //    sw.WriteLine(false);
        //    sw.WriteLine(Math.PI);
        //    sw.Flush();
        //    fs.Close();

        //    fs = new FileStream("Stream.txt", FileMode.Open, FileAccess.Read);
        //StreamReader sr = new StreamReader(fs);
        //Console.WriteLine(sr.ReadToEnd());
        //    fs.Close();

    }
}
