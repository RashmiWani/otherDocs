﻿namespace Q2
{
    partial class FormNetEditor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuNetEditor = new System.Windows.Forms.MenuStrip();
            this.docMenuStrip = new System.Windows.Forms.ToolStripMenuItem();
            this.docNewItem = new System.Windows.Forms.ToolStripMenuItem();
            this.docOpenItem = new System.Windows.Forms.ToolStripMenuItem();
            this.docCloseItem = new System.Windows.Forms.ToolStripMenuItem();
            this.docSaveItem = new System.Windows.Forms.ToolStripMenuItem();
            this.docExitItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuNetEditor.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuNetEditor
            // 
            this.menuNetEditor.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.docMenuStrip});
            this.menuNetEditor.Location = new System.Drawing.Point(0, 0);
            this.menuNetEditor.Name = "menuNetEditor";
            this.menuNetEditor.Size = new System.Drawing.Size(484, 24);
            this.menuNetEditor.TabIndex = 1;
            this.menuNetEditor.Text = "menuStrip1";
            // 
            // docMenuStrip
            // 
            this.docMenuStrip.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.docNewItem,
            this.docOpenItem,
            this.docCloseItem,
            this.docSaveItem,
            this.docExitItem});
            this.docMenuStrip.Name = "docMenuStrip";
            this.docMenuStrip.Size = new System.Drawing.Size(75, 20);
            this.docMenuStrip.Text = "Document";
            // 
            // docNewItem
            // 
            this.docNewItem.Name = "docNewItem";
            this.docNewItem.Size = new System.Drawing.Size(152, 22);
            this.docNewItem.Text = "New";
            this.docNewItem.Click += new System.EventHandler(this.docNewItem_Click);
            // 
            // docOpenItem
            // 
            this.docOpenItem.Name = "docOpenItem";
            this.docOpenItem.Size = new System.Drawing.Size(152, 22);
            this.docOpenItem.Text = "Open ";
            this.docOpenItem.Click += new System.EventHandler(this.docOpenItem_Click);
            // 
            // docCloseItem
            // 
            this.docCloseItem.Name = "docCloseItem";
            this.docCloseItem.Size = new System.Drawing.Size(152, 22);
            this.docCloseItem.Text = "Close";
            this.docCloseItem.Click += new System.EventHandler(this.docCloseItem_Click);
            // 
            // docSaveItem
            // 
            this.docSaveItem.Name = "docSaveItem";
            this.docSaveItem.Size = new System.Drawing.Size(152, 22);
            this.docSaveItem.Text = "Save ";
            this.docSaveItem.Click += new System.EventHandler(this.docSaveItem_Click);
            // 
            // docExitItem
            // 
            this.docExitItem.Name = "docExitItem";
            this.docExitItem.Size = new System.Drawing.Size(152, 22);
            this.docExitItem.Text = "Exit";
            this.docExitItem.Click += new System.EventHandler(this.docExitItem_Click);
            // 
            // FormNetEditor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(484, 461);
            this.Controls.Add(this.menuNetEditor);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuNetEditor;
            this.Name = "FormNetEditor";
            this.Text = "NetEditor";
            this.menuNetEditor.ResumeLayout(false);
            this.menuNetEditor.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuNetEditor;
        private System.Windows.Forms.ToolStripMenuItem docMenuStrip;
        private System.Windows.Forms.ToolStripMenuItem docNewItem;
        private System.Windows.Forms.ToolStripMenuItem docOpenItem;
        private System.Windows.Forms.ToolStripMenuItem docCloseItem;
        private System.Windows.Forms.ToolStripMenuItem docSaveItem;
        private System.Windows.Forms.ToolStripMenuItem docExitItem;
    }
}

