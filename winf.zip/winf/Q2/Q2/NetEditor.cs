﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Q2
{
    public partial class FormNetEditor : Form
    {
        public FormNetEditor()
        {
            InitializeComponent();
        }

        private void docNewItem_Click(object sender, EventArgs e)
        {
            FormNetEditorChild nec = new FormNetEditorChild();
            nec.Text = "New Document";
            nec.MdiParent = this;
            nec.Show();
        }

        private void docOpenItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog1 = new OpenFileDialog();
            openFileDialog1.Filter = "Text Files|*.txt|XML Files|*.xml";
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                StreamReader sr = new StreamReader(File.OpenRead(openFileDialog1.FileName));
                FormNetEditorChild nec = new FormNetEditorChild();
                nec.Text = openFileDialog1.FileName;
                nec.txtOpenWindow.Text = sr.ReadToEnd();
                sr.Close();
                nec.MdiParent = this;
                nec.Show();
            }
        }

        private void docCloseItem_Click(object sender, EventArgs e)
        {
            if (this.ActiveMdiChild != null)
                this.ActiveMdiChild.Close();
        }

        private void docExitItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void docSaveItem_Click(object sender, EventArgs e)
        {
            FormNetEditorChild nec = new FormNetEditorChild();
            SaveFileDialog sv = new SaveFileDialog();
            if (sv.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                FileStream fs = new FileStream(sv.FileName, FileMode.Create, FileAccess.Write);
                StreamWriter sw = new StreamWriter(fs);

                //TextWriter txt = new StreamWriter(fs);
                string txtdata = (string)nec.txtOpenWindow.Text;
                sw.Write(txtdata);
                fs.Close();
            }
        }
    }
}
