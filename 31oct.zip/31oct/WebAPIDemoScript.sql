create table Rashmi.WEBEmployee 
(
E_ID int primary key,
E_NAME varchar(30),
E_CITY varchar(20),
E_PHONE bigint
)

insert into Rashmi.WEBEmployee values (11,'Daksh','Pune',9807122345)
insert into Rashmi.WEBEmployee values (12,'Aarushi','Mumbai',9997122345)
insert into Rashmi.WEBEmployee values (13,'Priti','Hydrabad',8887122345)
insert into Rashmi.WEBEmployee values (14,'Abhishek','Pune',9907122345)

select * from Rashmi.WEBEmployee

select @@SERVERNAME