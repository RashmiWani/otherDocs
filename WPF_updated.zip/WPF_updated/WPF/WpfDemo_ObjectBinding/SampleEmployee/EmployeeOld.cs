﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SampleEmployee
{
   public class EmployeeOld
    {
        public int EmployeeId { get; set; }
        public string EmployeeName { get; set; }
        public string Department { get; set; }
    }

   public class EmpOldDetails
    {
       public EmployeeOld GetOldEmployeeDetails()
       {
           EmployeeOld oldEmp = new EmployeeOld { EmployeeId = 1010, EmployeeName = "Sangeetha", Department = "Training" };
           return oldEmp;
        
       }
    }
}
