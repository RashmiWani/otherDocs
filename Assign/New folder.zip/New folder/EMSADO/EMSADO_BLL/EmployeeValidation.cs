﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using EMSADO_Entity;
using EMSADO_Exception;
using ADOEMS_DAL;



namespace EMSADO_BLL
{
    public class EmployeeValidation
    {
        EmployeeOperation empOperation;
        public DataTable LoadDeparment_BLL()
        {
            DataTable dtDept;
            try
            {
                empOperation = new EmployeeOperation();
                dtDept = empOperation.LoadDeparment();
            }
            catch (SqlException se)
            {

                throw se;
            }
            catch (Exception ex)
            {

                throw ex;
            }
            return dtDept;
        }

        public DataTable GetEmployee_BLL()
        {
            DataTable dtEmp;
            try
            {
                empOperation = new EmployeeOperation();
                dtEmp = empOperation.GetEmployee_DAL();
            }
            catch (SqlException se)
            {

                throw se;
            }
            catch (Exception ex)
            {

                throw ex;
            }
            return dtEmp;
        }

        public bool validateEmp(Employee newEmp)
        {
            bool isValidEmp = true;
            StringBuilder sbError = new StringBuilder();
            try
            {
                if (newEmp.EmpName == string.Empty)
                {
                    isValidEmp = false;
                    sbError.Append("Please enter Employee Name");
                }
                if (!isValidEmp) throw new EmployeeException(sbError.ToString());
            }
            catch (EmployeeException ex)
            { throw ex; }

            return isValidEmp;
        }

        public int AddEmployee_BLL(Employee newEmp)
        {
            int rowsAffected = 0;
            EmployeeOperation operationObj;
            try
            {
                if (validateEmp(newEmp))
                {
                    operationObj = new EmployeeOperation();
                    rowsAffected = operationObj.AddEmployee_DAL(newEmp);
                }
            }
            catch (EmployeeException ex) { throw ex; }
            catch (SqlException se) { throw se; }
            catch (Exception ex) { throw ex; }
            return rowsAffected;

        }

        public DataTable GetEmployeeByID_BLL()
        {
            DataTable dtEmp;
            try
            {
                empOperation = new EmployeeOperation();

                dtEmp = empOperation.GetEmployeeByID_DAL();

            }
            catch (SqlException)
            {

                throw;
            }
            catch (Exception)
            {

                throw;
            }
            finally
            {


            }
            return dtEmp;

        }
        }
}
