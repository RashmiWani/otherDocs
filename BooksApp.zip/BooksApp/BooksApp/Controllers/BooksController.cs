﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using BooksApp.Models;

namespace BooksApp.Controllers
{
    public class BooksController : ApiController
    {
        List<Book> booklist = new List<Book>()
        {
            new Book {Id=70536,Title="Programming in C#",Genre="Programming",Year=2013,Price=999.99M},
            new Book {Id=70486,Title="Programming Asp.Net MVC 4",Genre="Programming",Year=2014,Price=1235.88M},
            new Book {Id=1008,Title="Microprocessors",Genre="Computers",Year=2005,Price=678.00M},
            new Book {Id=2341,Title="Cisco Certification",Genre="Networking",Year=2010,Price=3456.99M}
        };
        
        public IEnumerable<Book> GetBook()
        {
            return booklist;
        }

        
        public IHttpActionResult GetBook(int id)
        {
            var book = booklist.FirstOrDefault((b) => b.Id == id);

            if (book == null)
            {
                return NotFound();
            }

            return Ok(book);
        }

        public void PostBook(Book book)
        {
            if (book == null)
            {
                throw new ArgumentException("Invalid Object");
            }

            booklist.Add(book);
        }

        public void DeleteBook(int id)
        {
            booklist.RemoveAll(b => b.Id == id);
        }
    }
}
