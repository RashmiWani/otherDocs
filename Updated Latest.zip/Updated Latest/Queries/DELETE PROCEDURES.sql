use Sep19CHN

--DELETE PROCEDURES
--CLERK PROCEDURES
--DELETE EMPLOYEE
CREATE PROC Group4.usp_DeleteEmployee
(
	@Employee_Id		INT
)
AS
BEGIN
	DELETE FROM Group4.Employee
	WHERE Employee_Id = @Employee_Id
END
GO

--DELETE PROJECTS
CREATE PROC Group4.usp_DeleteProjects
(
	@Project_Id		INT
)
AS
BEGIN
	DELETE FROM Group4.Project
	WHERE Project_Id = @Project_Id
END
GO

--DELETE SKILLS
CREATE PROC Group4.usp_DeleteSkills
(
	@Skill_Id		INT
)
AS
BEGIN
	DELETE FROM Group4.Skill
	WHERE Skill_Id = @Skill_Id
END
GO

--DELETE CATEGORIES
CREATE PROC Group4.usp_DeleteCategory
(
	@Category_Id		INT
)
AS
BEGIN
	DELETE FROM Group4.Category
	WHERE Category_Id = @Category_Id
END
GO

--ADMIN PROCEDURES
--DELETE USER
CREATE PROC Group4.usp_DeleteUser
(
	@UserId		INT
)
AS
BEGIN
	DELETE FROM Group4.Users
	WHERE UserId = @UserId
END
GO

--DELETE CIVILSTATUS
CREATE PROC Group4.usp_DeleteCivilStatus
(
	@Status_Id		INT
)
AS
BEGIN
	DELETE FROM Group4.Civil_Status
	WHERE Status_Id = @Status_Id
END
GO
