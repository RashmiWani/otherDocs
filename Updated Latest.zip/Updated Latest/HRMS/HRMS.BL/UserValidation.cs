﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HRMS.Entity;
using HRMS.Exception;
using HRMS.DAL;
using System.Data.SqlClient;
using System.Data;

namespace HRMS.BL
{
    public class UserValidation
    {
        //Signup Code Validation 
        public static bool ValidateUser(Users newUser)
        {
            bool isValidUser = true;
            StringBuilder sbError = new StringBuilder();
            try
            {
                if (newUser.FirstName == string.Empty || newUser.LastName == string.Empty)
                {
                    isValidUser = false;
                    sbError.Append("Please Enter Complete Name");
                }
                if(newUser.Password == string.Empty)
                {
                    isValidUser = false;
                    sbError.Append("\nPlease Enter Password");
                }
                
                if (!isValidUser)
                    throw new HRMSException(sbError.ToString());
            }
            catch (HRMSException ex)
            {
                throw ex;
            }

            return isValidUser;
        }

        //Add User Validation
        public static int AddUser_BLL(Users newUser)
        {
            int rowsAffected = 0;
            try
            {
                if (ValidateUser(newUser))
                {
                    rowsAffected = Users_DAL.AddClerk(newUser);
                }
                else
                    throw new HRMSException("\nPlease provide valid User Information");
            }
            catch (HRMSException ex) { throw ex; }
            catch (SqlException se) { throw se; }
            catch (SystemException ex) { throw ex; }
            return rowsAffected;

        }

        //Method to verify Login Credentials
        
    }
}

