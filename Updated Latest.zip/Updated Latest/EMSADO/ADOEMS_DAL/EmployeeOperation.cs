﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using EMSADO_Entity;
using EMSADO_Exception;

namespace ADOEMS_DAL
{
    /// <summary>
    /// Employee ID :
    /// Employee Name :
    /// Description : Data Handling Class
    /// Date of Creation : 
    /// </summary>
    public class EmployeeOperation
    {
        //Function Load Department Table
        public static DataTable LoadDeparment()
        {
            DataTable dtDept;
            SqlDataReader empReader = null;
            try
            {
                //Creating command object
                SqlCommand empCommand = DataConnection.GenerateCommand();

                dtDept = new DataTable();
                empCommand.CommandText = "Manish.usp_DisplayDept";
                empCommand.Connection.Open();
                empReader = empCommand.ExecuteReader();
                dtDept.Load(empReader);
                empReader.Close();
                empCommand.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dtDept;
        }

        //Function to add Employee to Database
        public static int AddEmployee_DAL(Employee emp)
        {
            int rowsAffected = 0;
            try
            {
                //Creating command object
                SqlCommand empCommand = DataConnection.GenerateCommand();

                //Assigning command text
                empCommand.CommandText = "Manish.usp_AddEmployeeDept";

                //Adding parameters to command
                empCommand.Parameters.AddWithValue("@ename", emp.EmpName);
                empCommand.Parameters.AddWithValue("@eLoc", emp.EmpLocation);
                empCommand.Parameters.AddWithValue("@ePh", emp.EmpPhone);
                empCommand.Parameters.AddWithValue("@deId", emp.DeptId);

                //Executing command
                empCommand.Connection.Open();
                rowsAffected = empCommand.ExecuteNonQuery();
                empCommand.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return rowsAffected;
        }

        //Funtion to Update Employee Details
        public static int UpdateEmployee_DAL(Employee emp)
        {
            int rowsAffected = 0;
            try
            {
                //Creating command object
                 SqlCommand empCommand = DataConnection.GenerateCommand();
                //Assigning command text

                empCommand.CommandText = "Manish.usp_updateEmployeeDept";
                empCommand.Parameters.AddWithValue("@eID", emp.EmpId);
                empCommand.Parameters.AddWithValue("@ename", emp.EmpName);
                empCommand.Parameters.AddWithValue("@eLoc", emp.EmpLocation);
                empCommand.Parameters.AddWithValue("@ePh", emp.EmpPhone);
                empCommand.Parameters.AddWithValue("@deId", emp.DeptId);
                empCommand.Connection.Open();
                rowsAffected = empCommand.ExecuteNonQuery();
                empCommand.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return rowsAffected;
        }

        //Function to delete Employee Details
        public static int DeleteEmployee_DAL(int empId)
        {
            int rowsAffected = 0;
            try
            {
                //Creating command object
                SqlCommand empCommand = DataConnection.GenerateCommand();
                //Assigning command text

                empCommand.CommandText = "Manish.usp_DeleteEmployeeDept";
                empCommand.Parameters.AddWithValue("@eid", empId);
                
                empCommand.Connection.Open();
                rowsAffected = empCommand.ExecuteNonQuery();
                empCommand.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return rowsAffected;

        }

        //Function to display Employee Details
        public static DataTable GetEmployee_DAL()
        {
            DataTable dtEmp;
            SqlDataReader empReader = null;
            try
            {
                //Creating command object
                SqlCommand empCommand = DataConnection.GenerateCommand();

                dtEmp = new DataTable();
                empCommand.CommandText = "Manish.usp_DisplayEmployeeDept";
                empCommand.Connection.Open();
                empReader = empCommand.ExecuteReader();
                if (empReader.HasRows)
                {
                    dtEmp.Load(empReader);
                }
                empReader.Close();
                empCommand.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            
            return dtEmp;
        }

        //Function to Search Employee by Id
        public static DataTable GetEmployeeByID_DAL(int empid)
        {
            DataTable dtEmp;
            SqlDataReader empReader = null;
            try
            {
                //Creating command object
                SqlCommand empCommand = DataConnection.GenerateCommand();

                dtEmp = new DataTable(/*int EmpId*/);
                empCommand.CommandText = "Manish.usp_SearchEmployeeDept";
                empCommand.Parameters.AddWithValue("@eid", empid);
                empCommand.Connection.Open();
                empReader = empCommand.ExecuteReader();
                if (empReader.HasRows)
                {
                    dtEmp.Load(empReader);
                }
                empReader.Close();
                empCommand.Connection.Close();
            }
            catch (SqlException ex) 
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dtEmp;
        }

        //Function to get autogenerated Employee Id
        public static int GetAutoGeneratedId()
        {
            int newEmpId;
            try
            {
                SqlConnection connObj = new SqlConnection(@"Data Source=LAPTOP-L0AE0JE4\SQLEXPRESS;Initial Catalog=Viraj;Integrated Security=True");
                SqlCommand cmdObj = new SqlCommand("select IDENT_CURRENT('Manish.EmployeeDept')+ident_incr('Manish.EmployeeDept')", connObj);
                connObj.Open();
                object objResult = cmdObj.ExecuteScalar();
                newEmpId = Convert.ToInt32(objResult);
                connObj.Close();// return single data - obj
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch(Exception ex)
            {
                throw ex;
            }
            return newEmpId;

        }

    }
}
