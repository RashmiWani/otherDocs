﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using EMSADO_Entity;
using EMSADO_Exception;
using EMSADO_BLL;

namespace ADOEMS_PL
{
    /// <summary>
    /// Interaction logic for UpdateDetails.xaml
    /// </summary>
    public partial class UpdateDetails : Window
    {
      
        public UpdateDetails()
        {
            InitializeComponent();
        }
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            DataTable dtDept = EmployeeValidation.LoadDeparment_BLL();
            if (dtDept.Rows.Count >= 0)
            {
                cmb_DeptName.ItemsSource = dtDept.DefaultView;

                cmb_DeptName.DisplayMemberPath = "DeptName";
                cmb_DeptName.SelectedValuePath = "DeptId";
            }

            MainWindow mw = new MainWindow();
            // int empid = Convert.ToInt32(mw.txt_ID_Search.Text);
            int empid = mw.returnID();
            DataTable sEd = EmployeeValidation.GetEmployeeByID_BLL(empid);
            
            DataRow dr = sEd.Rows[0];
            if (!dr.IsNull("EmpId"))
            {
                txt_EmpId.Text = dr["EmpId"].ToString();
                txt_EmpName.Text = dr["EmpName"].ToString();
                txt_Location.Text = dr["EmpLocation"].ToString();
                txt_EmpPhNo.Text = dr["EmpContact"].ToString();
            }
            else
                MessageBox.Show("No Records found with Emp Id : " + empid);
        }

        //update details
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Employee newEmp = new Employee();

                newEmp.EmpId = Convert.ToInt32(txt_EmpId.Text);
                newEmp.EmpName = txt_EmpName.Text;
                newEmp.EmpLocation = txt_Location.Text;
                newEmp.EmpPhone = Convert.ToInt64(txt_EmpPhNo.Text);
                newEmp.DeptId = int.Parse(cmb_DeptName.SelectedValue.ToString());

                int rowsAffected = EmployeeValidation.UpdateEmployee_BLL(newEmp);
                if (rowsAffected > 0)
                { MessageBox.Show("Employee Details Updated !!"); }
                else MessageBox.Show("Error!!! Employee Record not Updated");
            }
            catch (EmployeeException ex)
            {
                MessageBox.Show(ex.Message);

            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
        }

        //Delete Employee
        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            try
            {
                int empId = Convert.ToInt32(txt_EmpId.Text);
               
                int rowsAffected = EmployeeValidation.DeleteEmployee_BLL(empId);
                if (rowsAffected > 0)
                {
                    txt_EmpId.Clear();
                    txt_EmpName.Clear();
                    txt_EmpPhNo.Clear();
                    txt_Location.Clear();
                    MessageBox.Show("Employee Details Deleted !!");
                }
                else MessageBox.Show("Error!!! Employee Record not found");
            }
            catch (EmployeeException ex)
            {
                MessageBox.Show(ex.Message);

            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }

        }
    }
}
