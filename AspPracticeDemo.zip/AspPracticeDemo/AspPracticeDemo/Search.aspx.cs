﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace AspPracticeDemo
{
    public partial class Search : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Training"].ConnectionString);
        SqlCommand cmd = null;
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            cmd = new SqlCommand("SELECT * FROM Manish.Student_master WHERE stud_Code = @SCode", con);
            cmd.Parameters.AddWithValue("@SCode", txtCode.Text);

            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.HasRows)
            {
                dr.Read();
                txtName.Text = dr["stud_Code"].ToString();
                txtName.Text = dr["Stud_Name"].ToString();
                txtDob.Text = dr["Srud_DOB"].ToString();
                txtAddress.Text = dr["Stud_City"].ToString();

               

                txtName.Enabled = true;
                txtDob.Enabled = true;
                txtAddress.Enabled = true;
                btnUpdate.Enabled = true;
                btnDelete.Enabled = true;
            }
            else
            {
                Response.Write("<SCRIPT type='text/javascript'>alert('Student Data not found for Stud Code " + txtCode.Text + "');</SCRIPT>");
            }
        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            cmd = new SqlCommand("UPDATE Manish.Student_master SET Stud_Name=@SName, Srud_DOB=@DOB, Stud_City=@Address WHERE stud_Code=@SCode", con);
            cmd.Parameters.AddWithValue("@SName", txtName.Text);
            cmd.Parameters.AddWithValue("@DOB", Convert.ToDateTime(txtDob.Text));
            cmd.Parameters.AddWithValue("@Address", txtAddress.Text);
            cmd.Parameters.AddWithValue("@SCode", txtCode.Text);

            //stud_Code Stud_Name   Srud_DOB Stud_City

            con.Open();
            int recordsAffected = cmd.ExecuteNonQuery();
            con.Close();

            if (recordsAffected > 0)
            {
                Response.Write("<SCRIPT type='text/javascript'>alert('Student Data updated for Stud Code " + txtCode.Text + "');</SCRIPT>");
                txtName.Enabled = false;
                txtDob.Enabled = false;
                txtAddress.Enabled = false;
                btnUpdate.Enabled = false;
                btnDelete.Enabled = false;
            }
            else
                Response.Write("<SCRIPT type='text/javascript'>alert('Student Data not updated for Stud Code " + txtCode.Text + "');</SCRIPT>");
        }

        protected void btnDelete_Click(object sender, EventArgs e)
        {
            cmd = new SqlCommand("DELETE FROM Manish.Student_master WHERE stud_Code=@SCode", con);
            cmd.Parameters.AddWithValue("@SCode", txtCode.Text);

            //stud_Code Stud_Name   Srud_DOB Stud_City

            con.Open();
            int recordsAffected = cmd.ExecuteNonQuery();
            con.Close();

            if (recordsAffected > 0)
            {
                Response.Write("<SCRIPT type='text/javascript'>alert('Student Data deleted for Stud Code " + txtCode.Text + "');</SCRIPT>");
                txtName.Enabled = false; 
                txtDob.Enabled = false;
                txtAddress.Enabled = false;
                btnUpdate.Enabled = false;
                btnDelete.Enabled = false;
            }
            else
                Response.Write("<SCRIPT type='text/javascript'>alert('Student Data not deleted for Stud Code " + txtCode.Text + "');</SCRIPT>");
        }
    }
}