﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GPB.Exception
{
    /// <summary>
    /// Employee ID : 161611
    /// Employee Name : Manish Rahangdale
    /// Description : This is an Exception Class for GuestPhoneBook
    /// Date of Modification : 6th Oct 2018
    /// </summary>
    public class GuestException : ApplicationException
    {
        //Default Constructor
        public GuestException() : base()
        { }

        //Parameterized constructor with message parameter
        public GuestException(string message) : base(message)
        { }

        //Parameterized constructor with message parameter and System.Exception innerException
        public GuestException(string message, System.Exception innerException) : base(message, innerException)
        { }

    }
}
