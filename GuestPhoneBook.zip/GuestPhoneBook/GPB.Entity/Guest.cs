﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GPB.Entity
{
    /// <summary>
    /// Employee ID : 161616
    /// Employee Name : Rashmi Wani
    /// Description : This is an Entity Class for PhoneBook
    /// Date of Modification : 6th Oct 2018
    /// </summary>
    public class Guest
    {
        //Get or Set Guest ID
        private int guest_id;
        public int GuestID
        {
            get { return guest_id; }
            set { guest_id = value; }
        }

        //Get or Set Guest Name
        private string guest_name;
        public string GuestName
        {
            get { return guest_name; }
            set { guest_name = value; }
        }

        // Get or Set Enumeration values
        public Relation relationShip
        {
            get { return relationShip; }
            set { relationShip = value; }
        }

        //Get or Set Contact Number
        private string contact_number;
        public string ContactNumber
        {
            get { return contact_number; }
            set { contact_number = value; }
        }
        public Guest()
        {
            guest_id = GuestID;
            guest_name = GuestName;
            contact_number = ContactNumber;
        }

        //Enumeration
        public enum Relation
        {
            FATHER , MOTHER, BROTHER, SISTER, COUSIN, UNCLE, AUNT, SON, DAUGHTER, FRIEND
        }
    }
}
