﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Text;
using System.Threading.Tasks;

using GPB.Entity;       //Reference for guest entity
using GPB.Exception;    //Reference for guest Exception class
using GPB.DAL;          //Reference for guest Data Access Layer class

namespace GPB.BL
{
    /// <summary>
    /// Employee ID : 161616
    /// Employee Name : Rashmi Wani
    /// Description : This class will have buisness logic for GuestPhoneBook
    /// Date of Modification : 6th Oct 2018
    /// </summary>
    public class GuestValidations
    {
        private static bool ValidateGuest(Guest gt)
        {

            bool isValidated = true;

            StringBuilder message = new StringBuilder();

            try
            {
                //Checking guest id that it should be of 6 digits
                if (gt.GuestID < 100000 || gt.GuestID > 999999)
                {
                    message.Append("Guest ID should be 6 digits long\n");
                    isValidated = false;
                }

                //Checking guest name
                if (gt.GuestName == string.Empty)
                {
                    message.Append("Guest Name should be provided\n");
                    isValidated = false;
                }
                else if (!Regex.IsMatch(gt.GuestName, "[A-Z][a-z]{2,}"))
                {
                    message.Append("Guest Name should start with Capital Alphabet, it should have minimum 3 characters and only alphabets\n");
                    isValidated = false;
                }

                //Checking Relation
                if (Guest.Relation.FATHER.ToString("FATHER").ToUpper() != "FATHER" &&
                    Guest.Relation.MOTHER.ToString("MOTHER").ToUpper() != "MOTHER" &&
                    Guest.Relation.AUNT.ToString("AUNT").ToUpper() != "AUNT" &&
                    Guest.Relation.BROTHER.ToString("BROTHER").ToUpper() != "BROTHER" &&
                    Guest.Relation.COUSIN.ToString("COUSIN").ToUpper() != "COUSIN" &&
                    Guest.Relation.DAUGHTER.ToString("DAUGHTER").ToUpper() != "DAUGHTER" &&
                    Guest.Relation.FRIEND.ToString("FRIEND").ToUpper() != "FRIEND" &&
                    Guest.Relation.SISTER.ToString("SISTER").ToUpper() != "SISTER" &&
                    Guest.Relation.SON.ToString("SON").ToUpper() != "SON" &&
                    Guest.Relation.UNCLE.ToString("UNCLE").ToUpper() != "UNCLE")
                {
                    message.Append("Relation should be one of : FATHER , MOTHER, BROTHER, SISTER, COUSIN, UNCLE, AUNT, SON, DAUGHTER, FRIEND \n");
                    isValidated = false;
                }

                //Checking Contact Number
                if (!Regex.IsMatch(gt.ContactNumber, "[7-9][0-9]{9}"))
                {
                    message.Append("Phone number should start with 7 or 8 or 9 and it should have exactly 10 digits\n");
                    isValidated = false;
                }

                if (isValidated == false)
                    throw new GuestException(message.ToString());
            }
            catch (GuestException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return isValidated;
        }

        //Method to add new employee
        public static bool AddGuest(Guest gt)
        {
            bool isAdded = false;
            try
            {
                //Validating guest details
                if (ValidateGuest(gt))
                {
                    //Adding the guest by calling DAL Add method
                    isAdded = GuestOperations.AddGuest(gt);
                }
                else
                    throw new GuestException("Please provide valid guest details");
            }
            catch (GuestException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return isAdded;
        }

        //Method to display all guests
        public static List<Guest> ListAllGuest()
        {
            List<Guest> guestList = null;

            try
            {
                //displaying employee by calling DAL display method
                guestList = GuestOperations.ListAllGuest();
            }
            catch (GuestException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return guestList;
        }


        //Method to search guest by ID
        public static Guest SearchGuestByID(int guestID)
        {
            Guest gt = null;
            try
            {
                //Searching employee by calling DAL search method
                gt = GuestOperations.SearchGuestByID(guestID);
            }
            catch (GuestException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return gt;
        }

        //Method to search employee by Relationship name
        public static List<Guest> SearchGuestByRelationship(Guest.Relation gr)
        {
            List<Guest> lg = null;

            try
            {
                //Searching guest by calling DAL search method
                lg = GuestOperations.SearchGuestByRelationship(gr);
            }
            catch (GuestException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return lg;
        }

        //Method to update guest details
        public static bool UpdateGuestDetails(Guest gt)
        {
            bool isUpdated = false;
            try
            {
                //Validating guest details
                if (ValidateGuest(gt))
                {
                    //Updating the update details by calling DAL Update method
                    isUpdated = GuestOperations.UpdateGuestDetails(gt);
                }
                else
                    throw new GuestException("Please provide valid guest details");
            }
            catch (GuestException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return isUpdated;
        }

        //Method to delete guest details
        public static bool DeleteGuest(int guestID)
        {
            bool isDeleted = false;

            try
            {
                //Deleting employee by calling delete method of DAL
                isDeleted = GuestOperations.DeleteGuest(guestID);
            }
            catch (GuestException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return isDeleted;
        }
    }
}
