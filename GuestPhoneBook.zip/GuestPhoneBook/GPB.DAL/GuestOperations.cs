﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GPB.Entity;       //Reference for guest entity
using GPB.Exception;    //Reference for guest Exception class

namespace GPB.DAL
{
    /// <summary>
    /// Employee ID : 161616
    /// Employee Name : Rashmi Wani
    /// Description : This class will provide CRUD operations for GuestPhoneBook
    /// Date of Modification : 6th Oct 2018
    /// </summary>
    public class GuestOperations
    {
        static List<Guest> guestList = new List<Guest>();

        //Method to add new guest
        public static bool AddGuest(Guest gt)
        {
            bool isAdded = false;
            try
            {
                //Adding guest in the list
                guestList.Add(gt);
                isAdded = true;
            }
            catch (GuestException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return isAdded;
        }

        //Method to display all guest
        public static List<Guest> ListAllGuest()
        {
            return guestList;
        }

        //Method to search guest information basedl on guest ID
        public static Guest SearchGuestByID(int guestID)
        {
            Guest gt = null;
            try
            {
                //Searching guest
                gt = guestList.Find(e => e.GuestID == guestID);
            }
            catch (GuestException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return gt;
        }

        //Method to search guest information on guest relationship
        public static List<Guest> SearchGuestByRelationship(Guest.Relation rel)
        {
            Guest gt = null;
            try
            {
                //Searching guest
                gt = guestList.Find(e => e.relationShip == rel);
            }
            catch (GuestException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return guestList;
        }

        //Method to update guest information
        public static bool UpdateGuestDetails(Guest gt)
        {
            bool isUpdated = false;

            try
            {
                for (int i = 0; i < guestList.Count; i++)
                {
                    //Searching guest for modification
                    if (guestList[i].GuestID == gt.GuestID)
                    {
                        //Modifying guest Details
                        guestList[i].GuestName = gt.GuestName;
                        guestList[i].relationShip = gt.relationShip;
                        guestList[i].ContactNumber = gt.ContactNumber;

                        isUpdated = true;
                    }
                }
            }
            catch (GuestException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return isUpdated;
        }

        //Method to delete particular guest
        public static bool DeleteGuest(int guestID)
        {
            bool isDeleted = false;

            try
            {
                //Searching the employee for delete
                Guest gt = guestList.Find(e => e.GuestID == guestID);

                if (gt != null)
                {
                    //Deleting Employee information
                    guestList.Remove(gt);
                    isDeleted = true;
                }
            }
            catch (GuestException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return isDeleted;
        }

    }
}
