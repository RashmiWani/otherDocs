﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using GPB.Entity;       //Reference for guest entity
using GPB.Exception;    //Reference for guest Exception class
using GPB.BL;          //Reference for guest buisness layer class

namespace GPB.PL
{
    /// <summary>
    /// Employee ID : 161611
    /// Employee Name : Manish Rahangdale
    /// Description : This class will have buisness logic for GuestPhoneBook
    /// Date of Modification : 7th Oct 2018
    /// </summary>
    class Program
    {
        //Method to add new guest
        public static void AddGuest()
        {
            try
            {
                Guest gst = new Guest();
                Console.Write("Enter Guest ID : ");
                gst.GuestID = Convert.ToInt32(Console.ReadLine());

                Console.Write("Enter Guest Name : ");
                gst.GuestName = Console.ReadLine();

                Console.Write("Your Relation[ FATHER , MOTHER, BROTHER, SISTER, COUSIN, UNCLE, AUNT, SON, DAUGHTER, FRIEND] : ");
                //string rel = Console.ReadLine();
                Guest.Relation relenum = (Guest.Relation)Enum.Parse(typeof(Guest.Relation), Console.ReadLine());
                gst.relationShip = relenum;
                Console.Write("Enter Phone Number : ");
                gst.ContactNumber = Console.ReadLine();

                bool isAdded = GuestValidations.AddGuest(gst);

                if (isAdded)
                {
                    Console.WriteLine("Guest details added successfully");
                }
                else
                    throw new GuestException("Guest details not added");
            }
            catch (GuestException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        //Method to display all guest
        public static void ListAllGuest()
        {
            try
            {
                List<Guest> guestList = GuestValidations.ListAllGuest();

                if (guestList != null || guestList.Count > 0)
                {
                    Console.WriteLine("*******************************************************************");
                    Console.WriteLine("Guest ID     Guest Name      Realation     Phone Number   ");
                    Console.WriteLine("*******************************************************************");
                    foreach (Guest gst in guestList)
                    {
                        Console.WriteLine(gst.GuestID + "\t" + gst.GuestName + "\t" + gst.relationShip + "\t" + gst.ContactNumber);
                    }
                    Console.WriteLine("*******************************************************************");
                }
                else
                    throw new GuestException("Guest Details not available");
            }
            catch (GuestException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void SearchGuestByID()
        {
            try
            {
                int guestID;

                Console.Write("Enter Guest ID for Search : ");
                guestID = Convert.ToInt32(Console.ReadLine());

                Guest gst = GuestValidations.SearchGuestByID(guestID);

                if (gst != null)
                {
                    Console.WriteLine("Guest ID : " + gst.GuestID);
                    Console.WriteLine("Guest Name : " + gst.GuestName);
                    Console.WriteLine("Relation with Guest : " + gst.relationShip);
                    Console.WriteLine("Guest Contach Number : " + gst.ContactNumber);

                }
                else
                    throw new GuestException("Guest " + guestID + " not found");
            }
            catch (GuestException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void SearchGuestByRelationship()
        {
            //Console.WriteLine("Enter Relationship: ");
            //Guest.Relation rel = (Guest.Relation)Enum.Parse(typeof(Guest.Relation), Console.ReadLine());

            try
            {
                Console.WriteLine("Enter Relationship: ");
                Guest.Relation rel = (Guest.Relation)Enum.Parse(typeof(Guest.Relation), Console.ReadLine());

                List<Guest> gst = GuestValidations.SearchGuestByRelationship(rel);

                if (gst != null)
                {
                    foreach(Guest gt in gst)
                    {
                        Console.WriteLine("Guest ID : " + gt.GuestID);
                        Console.WriteLine("Guest Name : " + gt.GuestName);
                        Console.WriteLine("Relation with Guest : " + gt.relationShip);
                        Console.WriteLine("Guest Contach Number : " + gt.ContactNumber);

                    }
                   

                }
                else
                    throw new GuestException("Guest " + rel + " not found");
            }
            catch (GuestException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }

        }

        public static void UpdateGuestDetails()
        {
            try
            {
                Guest gst = new Guest();
                Console.Write("Enter Guest ID to be updated: ");
                gst.GuestID = Convert.ToInt32(Console.ReadLine());

                Console.Write("Enter Modified Guest Name : ");
                gst.GuestName = Console.ReadLine();

                Console.Write("Enter RealtionSHip  : ");
                string rel = Console.ReadLine();
                Guest.Relation relnum = (Guest.Relation)Convert.ToInt32(rel);

                Console.Write("Enter Modified Phone Number : ");
                gst.ContactNumber = Console.ReadLine();



                bool isUpdated = GuestValidations.UpdateGuestDetails(gst);

                if (isUpdated)
                {
                    Console.WriteLine("Guest details updated successfully");
                }
                else
                    throw new GuestException("Guest details not updated");
            }
            catch (GuestException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void DeleteGuest()
        {
            try
            {
                int guestID;

                Console.Write("Enter Guest ID to be Deleted : ");
                guestID = Convert.ToInt32(Console.ReadLine());

                bool isDeleted = GuestValidations.DeleteGuest(guestID);

                if (isDeleted)
                {
                    Console.WriteLine("Guest " + guestID + " deleted successfully");
                }
                else
                    throw new GuestException("Guest " + guestID + " not deleted");
            }
            catch (GuestException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void PrintMenu()
        {
            Console.WriteLine("----------------------------");
            Console.WriteLine("1. Add Guest");
            Console.WriteLine("2. List All Guest");
            Console.WriteLine("3. Search Guest By ID");
            Console.WriteLine("4. Search Guest By Relation");
            Console.WriteLine("5. Update Guest Deatils");
            Console.WriteLine("6. Delate Guest Deatils");
            Console.WriteLine("7. Exit");
            Console.WriteLine("----------------------------");
        }

        static void Main(string[] args)
        {
            try
            {
                int choice;
                do
                {
                    PrintMenu();
                    Console.Write("Enter your choice : ");
                    choice = Convert.ToInt32(Console.ReadLine());

                    switch (choice)
                    {
                        case 1:
                            AddGuest();
                            break;
                        case 2:
                            ListAllGuest();
                            break;
                        case 3:
                            SearchGuestByID();
                            break;
                        case 4:
                            SearchGuestByRelationship();
                            break;
                        case 5:
                            UpdateGuestDetails();
                            break;
                        case 6:
                            DeleteGuest();
                            break;
                        case 7:
                            Environment.Exit(0);
                            break;
                    
                        default:
                            Console.Write("Please enter a valid choice");
                            break;
                    }
                } while (choice != 7);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }

            Console.ReadKey();


        }
    }
}
