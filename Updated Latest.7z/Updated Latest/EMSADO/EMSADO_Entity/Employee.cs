﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMSADO_Entity
{
    /// <summary>
    /// Employee ID :
    /// Employee Name : 
    /// Description : This is entity class for the Employee information
    /// Date of Creation :
    /// </summary>
    public class Employee
    {
        public int EmpId { get; set; }
        public string EmpName { get; set; }
        public string EmpLocation { get; set; }
        public long EmpPhone { get; set; }
        public int DeptId { get; set; }
    }
}
