﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMSADO_Exception
{
    /// <summary>
    /// Employee ID :
    /// Employee Name :
    /// Description : The class for raising Employee spcific exceptions
    /// Date of Creation : 
    /// </summary>
    public class EmployeeException : ApplicationException
    {
        //Default constructor
        public EmployeeException()
            : base()
        { }

        //Parameterized constructor with message parameter
        public EmployeeException(string Message) : base(Message)
        { }

    }
}
