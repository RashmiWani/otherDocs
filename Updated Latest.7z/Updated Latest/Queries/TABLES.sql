    ---/// <summary>
    ---/// Employee ID :161585
    ---/// Employee Name : Viraj Dere
    ---/// Description : Table Creations
    ---/// Date of Creation : 10/19/2018
    ---/// </summary>

use Sep19CHN

CREATE SCHEMA Group4

--SPECIALITY TABLE
CREATE TABLE Group4.Speciality
(
	Speciality_Id INT IDENTITY(1100,1) PRIMARY KEY,
	Speciality_Name VARCHAR(20)
)

--LEVEL TABLE
CREATE TABLE Group4.Level_
(
	Level_Id INT IDENTITY(10,1) PRIMARY KEY,
	Level_Description VARCHAR(50)
)

--CIVIL STATUS TABLE
CREATE TABLE Group4.Civil_Status
(
	Status_Id INT IDENTITY(100,1) PRIMARY KEY,
	Status_Description VARCHAR(20)
)

--CATEGORY TABLE
CREATE TABLE Group4.Category
(
	Category_Id INT IDENTITY(100,1) PRIMARY KEY,
	Category_Name VARCHAR(20),
	Category_Description VARCHAR(50)
)

--PROJECT TABLE
CREATE TABLE Group4.Project
(
	Project_Id INT IDENTITY(1215,1) PRIMARY KEY,
	Project_Name VARCHAR(20),
	Project_Description VARCHAR(50),
	Project_Client VARCHAR(20),
	Project_Start_Date DATE,
	Project_End_Date DATE
)

--SKILL TABLE
CREATE TABLE Group4.Skill
(
	Skill_Id INT IDENTITY(201,1) PRIMARY KEY,
	Skill_Name VARCHAR(20),
	Skill_Description VARCHAR(50),
	Category_Id INT,
	FOREIGN KEY (Category_Id) REFERENCES Group4.Category(Category_Id)
)

--EMPLOYEE TABLE
CREATE TABLE Group4.Employee
(
	Employee_Id INT IDENTITY(1000,1) PRIMARY KEY,
	First_Name VARCHAR(10),
	Middle_Name VARCHAR(10),
	Last_Name VARCHAR(10),
	Birth_Date DATE,
	Age INT,
	Gender VARCHAR(10),
	Civil_Status INT,
	Religion VARCHAR(20),
	Citizenship VARCHAR(20),
	Mobile_No BIGINT,
	Home_Phone_No BIGINT,
	Address_ VARCHAR(100),
	City VARCHAR(20),
	State_ VARCHAR(20),
	Pincode BIGINT,
	Country VARCHAR(20),
	Project_Id INT,
	Skill_Id INT,
	Educational_Background VARCHAR(20),
	FOREIGN KEY (Civil_Status) REFERENCES Group4.Civil_Status(Status_Id),
	FOREIGN KEY (Project_Id) REFERENCES Group4.Project(Project_Id),
	FOREIGN KEY (Skill_Id) REFERENCES Group4.Skill(Skill_Id)
)

--CAPGEMINI DETAILS TABLE
CREATE TABLE Group4.Capgemini_Details
(
	Employee_Id INT NOT NULL ,
	Email VARCHAR(50),
	Level_Id INT NOT NULL,
	Date_Hired DATE,
	Speciality INT NOT NULL,
	Status_ INT NOT NULL,
	FOREIGN KEY(Employee_Id) REFERENCES Group4.Employee(Employee_Id),
	FOREIGN KEY(Level_Id) REFERENCES Group4.Level_(Level_Id),
	FOREIGN KEY(Speciality) REFERENCES Group4.Speciality(Speciality_Id),
	FOREIGN KEY(Status_) REFERENCES Group4.Civil_Status(Status_Id)
)

--USERS TABLE
CREATE TABLE Group4.Users
(
	UserId INT IDENTITY(1201,1) PRIMARY KEY,
	UserName VARCHAR(20),
	Password_ VARCHAR(20),
	First_Name VARCHAR(15),
	Last_Name VARCHAR(15)
)

--ROLES TABLE
CREATE TABLE Group4.Roles
(
	Role_Id INT IDENTITY(1510,1) PRIMARY KEY,
	Role_Name VARCHAR(20)
)

--USER ROLES TABLE
CREATE TABLE Group4.User_Roles
(
	UserId INT NOT NULL,
	Role_Id INT NOT NULL,
	FOREIGN KEY(UserId) REFERENCES Group4.Users(UserId),
	FOREIGN KEY(Role_Id) REFERENCES Group4.Roles(Role_Id)
)




select * from Group4.Users

--USER LOGIN PROCEDURES
--LOGIN VERIFICATION
CREATE PROC Group4.VerifyLogin
(
	@userName VARCHAR(20),
	@password VARCHAR(20)
)
AS
	BEGIN
		SELECT UserName,Password_ FROM Group4.Users
		WHERE  (UserName = @userName) AND (Password_ = @password)
	END


alter PROC [Group4].[VerifyLogin]
(
	@userName VARCHAR(20),
	@password VARCHAR(20),
	@roleId int 
)
AS
	BEGIN
		SELECT us.UserName,us.Password_,ur.Role_Id FROM Group4.Users us join Group4.User_Roles ur on us.UserId=ur.UserId
		WHERE  (us.UserName = @userName) AND (us.Password_ = @password) AND (ur.Role_Id=@roleId)
	END
GO
