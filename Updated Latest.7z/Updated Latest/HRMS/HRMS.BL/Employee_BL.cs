﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HRMS.Entity;
using HRMS.Exception;
using HRMS.DAL;
using System.Text.RegularExpressions;
namespace HRMS.BL
{
    class Employee_BL
    {
        public static bool ValidatEmployee(Employee newEmp)
        {
            bool isValidUser = true;
            StringBuilder sbError = new StringBuilder();
            try
            {
                if (newEmp.FirstName == string.Empty)
                {
                    isValidUser = false;
                    sbError.Append("Please Enter FirstName");
                }
                else if (!Regex.IsMatch(newEmp.FirstName, "[A-Z][a-z]{2,}"))
                {
                    sbError.Append("Employee first Name should start with Capital Alphabet, it should have minimum 3 characters and only alphabets\n");
                    isValidUser = false;
                }
                if (newEmp.MiddleName == string.Empty )
                {
                    isValidUser = false;
                    sbError.Append("Please Enter MiddleName");
                }
                else if (!Regex.IsMatch(newEmp.MiddleName, "[A-Z][a-z]{2,}"))
                {
                    sbError.Append("Employee Middle Name should start with Capital Alphabet, it should have minimum 3 characters and only alphabets\n");
                    isValidUser = false;
                }
                if (newEmp.LastName == string.Empty)
                {
                    isValidUser = false;
                    sbError.Append("Please Enter LastName");
                }
                else if (!Regex.IsMatch(newEmp.LastName, "[A-Z][a-z]{2,}"))
                {
                    sbError.Append("Employee Last Name should start with Capital Alphabet, it should have minimum 3 characters and only alphabets\n");
                    isValidUser = false;
                }
                int age = DateTime.Now.Year -newEmp.BirthDate.Year;
                if (age < 18)
                {
                    sbError.Append("Date of Birth should be proper so that Employee age will be > 18\n");
                    isValidUser = false;
                }
                if (newEmp.Age < 18)
                {
                    sbError.Append("Employee Age Should be 18 or 18+\n");
                    isValidUser = false;
                }

                if (!isValidUser)
                    throw new HRMSException(sbError.ToString());
            }
            catch (HRMSException ex)
            {
                throw ex;
            }

            return isValidUser;
        }

    }
}
