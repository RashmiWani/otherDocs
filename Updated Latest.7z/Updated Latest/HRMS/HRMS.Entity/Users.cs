﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRMS.Entity
{
    /// <summary>
    /// Employee ID :161585
    /// Employee Name : Viraj Dere
    /// Description : User Entity Class
    /// Date of Creation : 10/19/2018
    /// </summary>
    [MetadataType(typeof(Users))]
    public class Users
    {
        [Display(Name = "User ID")]
        public int UserId { get; set; }

        [Display(Name = "Username")]
        public string UserName { get; set; }
        public string Password { get; set; }

        [Display(Name = "First Name")]
        public string FirstName { get; set; }

        [Display(Name = "Last Name")]
        public string LastName { get; set; }
    }
}
