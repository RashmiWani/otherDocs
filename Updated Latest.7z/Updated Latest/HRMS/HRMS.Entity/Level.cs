﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRMS.Entity
{
    /// <summary>
    /// Employee ID :161585
    /// Employee Name : Viraj Dere
    /// Description : Level Entity Class
    /// Date of Creation : 10/19/2018
    /// </summary>
    public class Level
    {
        public int LevelId { get; set; }
        public string LevelDescription { get; set; }
    }
}
