﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using HRMS.Entity;
using HRMS.Exceptions;
using HRMS.BL;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

namespace HRMS
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void cmb_login_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void btn_clerk_signup_Click(object sender, RoutedEventArgs e)
        {
            Signup su = new Signup();
            su.Show();
        }

        private void btn_clerk_login_Click(object sender, RoutedEventArgs e)
        {
            //if (cmb_login.SelectedIndex == 0)
            //{
            //    HRClerkDatabase hrcd = new HRClerkDatabase();
            //    hrcd.Show();
            //}
            //else if (cmb_login.SelectedIndex == 1)
            //{
            //    AdminDatabase admindb = new AdminDatabase();
            //    admindb.Show();
            //}
            //else
            //{

            //}


            try
            {
                string username = txt_username.Text;
                string password = passBox_password.Password.ToString();
                int roleId = Convert.ToInt32(cmb_login.SelectedValue.ToString());
                bool valid = UserValidation.ClerkLogin(username,password,roleId);

                if (valid)
                {
                    if (roleId == 1510)
                    {
                        AdminDatabase Ad = new AdminDatabase();
                        Ad.Show();
                    }
                    else if (roleId == 1512)
                    {
                        HRClerkDatabase HC = new HRClerkDatabase();
                        HC.Show();
                    }
                }
                else
                    MessageBox.Show("Please Enter Valid Credentials");

            }
            catch (HRMSException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
        }

        private void HRMS_Loaded(object sender, RoutedEventArgs e)
        {
            DataTable dtRole =UserValidation.LoadUserRoles_BLL();
            if (dtRole.Rows.Count >= 0)
            {
                cmb_login.ItemsSource = dtRole.DefaultView;

                cmb_login.DisplayMemberPath = "Role_Name";
                cmb_login.SelectedValuePath = "Role_Id";
               
            }
        }
    }
}
