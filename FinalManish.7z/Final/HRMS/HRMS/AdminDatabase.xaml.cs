﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using HRMS.Entity;
using HRMS.Exceptions;
using HRMS.BL;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;


namespace HRMS
{
    /// <summary>
    /// Interaction logic for AdminDatabase.xaml
    /// </summary>
    public partial class AdminDatabase : Window
    {
        public AdminDatabase()
        {
            InitializeComponent();
        }

        //Admin Users
        private void btn_AdminUsers_Add_Click(object sender, RoutedEventArgs e)
        {

            try
            {
                Users user = new Users();
                UserRoles role = new UserRoles();
                user.UserId = Convert.ToInt32(textBox_AdminUsers_ID.Text);
                user.UserName = textBox_AdminUsers_Name.Text;
                user.Password = passBox_AdminUsers_Password.Password.ToString();
               // MessageBox.Show(user.Password);
                user.FirstName = textBox_AdminUsers_FirstName.Text;
                user.LastName = textBox_AdminUsers_LastName.Text;
           
                role.UserId = user.UserId;
                role.RoleId= Convert.ToInt32(cmb_role.SelectedValue.ToString());



                int rowsAffected = UserValidation.AddClerk_BLL(user,role);
                if (rowsAffected > 0)
                {
                    MessageBox.Show("User  Details Added Successfully");
                }
                else
                {
                    MessageBox.Show("Error!!! User Details not Added");
                }
            }
            catch (HRMSException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }

        }

        private void btn_AdminUsers_Display_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                DataTable dtUser = UserValidation.DisplayClerk_BLL();

                dg_AdminUsers_Details.ItemsSource = dtUser.DefaultView;
                // dg_display.ItemsSource = dtEmp.DefaultView;
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }

        }

        private void btn_AdminUsers_Delete_Click(object sender, RoutedEventArgs e)
        {
            try
            {

                int userId = Convert.ToInt32(textBox_AdminUsers_ID.Text);

                int rowsAffected = UserValidation.DeleteClerk_BLL(userId);
                if (rowsAffected > 0)
                {
                    MessageBox.Show("User Details Deleted Successfully");
                }
                else
                {
                    MessageBox.Show("Error!!! User Details not Deleted");
                }
            }
            catch (HRMSException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }

        }

        private void btn_AdminUsers_Update_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Users user = new Users();
                user.UserId = Convert.ToInt32(textBox_AdminUsers_ID.Text);
                user.UserName = textBox_AdminUsers_Name.Text;
                user.Password = passBox_AdminUsers_Password.Password.ToString();
                // MessageBox.Show(user.Password);
                user.FirstName = textBox_AdminUsers_FirstName.Text;
                user.LastName = textBox_AdminUsers_LastName.Text;


                int rowsAffected = UserValidation.UpdateClerk_BLL(user);
                if (rowsAffected > 0)
                {
                    MessageBox.Show("User  Details updated Successfully");
                }
                else
                {
                    MessageBox.Show("Error!!! User Details not updated");
                }
            }
            catch (HRMSException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }

        }

        private void btn_AdminUsers_Reset_Click(object sender, RoutedEventArgs e)
        {
            //textBox_AdminUsers_ID.Clear();
            textBox_AdminUsers_Name.Clear();
            passBox_AdminUsers_Password.Clear();
            textBox_AdminUsers_FirstName.Clear();
            textBox_AdminUsers_LastName.Clear();
        }

        private void btn_AdminUsers_Search_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                DataTable dtuser = UserValidation.SearchClerk_BLL(Convert.ToInt32(textBox_AdminUsers_ID.Text));
                DataRow dr = dtuser.Rows[0];
                if (!string.IsNullOrEmpty((dr["UserId"].ToString())))
                {
                    textBox_AdminUsers_ID.Text = dr["UserId"].ToString();
                    textBox_AdminUsers_Name.Text = dr["Username"].ToString();
                    passBox_AdminUsers_Password.Password = dr["Password_"].ToString();
                    textBox_AdminUsers_FirstName.Text = dr["First_Name"].ToString();
                    textBox_AdminUsers_LastName.Text = dr["Last_Name"].ToString();
                   
                }


            }
            catch (HRMSException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }


        }

        private void dg_AdminUsers_Details_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        //Admin Civil Status
        private void btn_Admin_CivilStatus_Add_Click(object sender, RoutedEventArgs e)
        {

            try
            {
                CivilStatus cs = new CivilStatus();
                cs.StatusId = Convert.ToInt32(textBox_Admin_CivilStatus_ID.Text);
                cs.StatusDescription = textBox_Admin_CivilStatus_Description.Text;

                int rowsAffected = CivilStatus_BL.AddCivilStatus_BL(cs);
                if (rowsAffected > 0)
                {
                    MessageBox.Show("Civil Status Details Added Successfully");
                }
                else
                {
                    MessageBox.Show("Error!!! Civil Status Details not Added");
                }
            }
            catch (HRMSException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }

        }

        private void btn_Admin_CivilStatus_Display_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                DataTable dtCs = CivilStatus_BL.DisplayCivilStatus_BL();

                dg_Admin_CivilStatus_Details.ItemsSource = dtCs.DefaultView;
                // dg_display.ItemsSource = dtEmp.DefaultView;
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }

        }

        private void btn_Admin_CivilStatus_Delete_Click(object sender, RoutedEventArgs e)
        {
            try
            {

                int csId = Convert.ToInt32(textBox_Admin_CivilStatus_ID.Text);

                int rowsAffected = Level_BL.DeleteLevel_BL(csId);
                if (rowsAffected > 0)
                {
                    MessageBox.Show("Civil Status Details Deleted Successfully");
                }
                else
                {
                    MessageBox.Show("Error!!! Civil Status Details not Deleted");
                }
            }
            catch (HRMSException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }

        }

        private void btn_Admin_CivilStatus_Update_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                CivilStatus cs = new CivilStatus();
                cs.StatusId = Convert.ToInt32(textBox_Admin_CivilStatus_ID.Text);
                cs.StatusDescription = textBox_Admin_CivilStatus_Description.Text;

                int rowsAffected = CivilStatus_BL.UpdateCivilStatus_BL(cs);
                if (rowsAffected > 0)
                {
                    MessageBox.Show("Civil Status Details Updated Successfully");
                }
                else
                {
                    MessageBox.Show("Error!!! Civil Status Details not Updated");
                }
            }
            catch (HRMSException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
        }

        private void btn_Admin_CivilStatus_Reset_Click(object sender, RoutedEventArgs e)
        {
            textBox_Admin_CivilStatus_ID.Clear();
            textBox_Admin_CivilStatus_Description.Clear();
        }

        private void btn_Admin_CivilStatus_Search_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                DataTable dtCs = CivilStatus_BL.SearchCivilStatusById_BL(Convert.ToInt32(textBox_Admin_CivilStatus_ID.Text));
                DataRow dr = dtCs.Rows[0];
                if (!string.IsNullOrEmpty((dr["Status_Id"].ToString())))
                {
                    textBox_Admin_CivilStatus_ID.Text = dr["Status_Id"].ToString();
                    textBox_Admin_CivilStatus_Description.Text = dr["Status_Description"].ToString();
                }


            }
            catch (HRMSException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }

        }

        private void dg_Admin_CivilStatus_Details_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        //Admin Level

        //Add Level Details
        private void btn_AdminLevel_Add_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                CivilStatus cs = new CivilStatus();
                cs.StatusId = Convert.ToInt32(textBox_Admin_CivilStatus_ID.Text);
                cs.StatusDescription = textBox_Admin_CivilStatus_Description.Text;

                int rowsAffected = CivilStatus_BL.UpdateCivilStatus_BL(cs);
                if (rowsAffected > 0)
                {
                    MessageBox.Show("Civil Status Details updated Successfully");
                }
                else
                {
                    MessageBox.Show("Error!!! Civil Status Details not Updated");
                }
            }
            catch (HRMSException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }


        }

        //Diplay Level Details
        private void btn_AdminLevel_Display_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                DataTable dtLev = Level_BL.DisplayLevel_BL();

                dg_AdminLevel_Details.ItemsSource = dtLev.DefaultView;
                // dg_display.ItemsSource = dtEmp.DefaultView;
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        //Delete Level Details
        private void btn_AdminLevel_Delete_Click(object sender, RoutedEventArgs e)
        {

            try
            {

                int levelId = Convert.ToInt32(textBox_AdminLevel_ID.Text);

                int rowsAffected = Level_BL.DeleteLevel_BL(levelId);
                if (rowsAffected > 0)
                {
                    MessageBox.Show("Level Details Deleted Successfully");
                }
                else
                {
                    MessageBox.Show("Error!!!Level Details not Deleted");
                }
            }
            catch (HRMSException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }

        }

        //Update Level Details
        private void btn_AdminLevel_Update_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Level lev = new Level();
                lev.LevelId = Convert.ToInt32(textBox_AdminLevel_ID.Text);
                lev.LevelDescription = textBox_AdminLevel_Description.Text;

                int rowsAffected = Level_BL.UpdateLevel_BL(lev);
                if (rowsAffected > 0)
                {
                    MessageBox.Show("Level Details Updated Successfully");
                }
                else
                {
                    MessageBox.Show("Error!!! Level Details not Updated");
                }
            }
            catch (HRMSException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
        }

        //Reset Fields on Level Page
        private void btn_AdminLevel_Reset_Click(object sender, RoutedEventArgs e)
        {
            textBox_AdminLevel_ID.Clear();
            textBox_AdminLevel_Description.Clear();
            textBox_AdminLevel_ID.Text = Level_BL.GetAutogeneratedLevelID_BL().ToString();


        }

        private void btn_AdminLevel_Search_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                DataTable dtLev = Level_BL.SearchLevelById_BL(Convert.ToInt32(textBox_AdminLevel_ID.Text));
                DataRow dr = dtLev.Rows[0];
                if (!string.IsNullOrEmpty((dr["Level_Id"].ToString())))
                {
                    textBox_AdminLevel_ID.Text = dr["Level_Id"].ToString();
                    textBox_AdminLevel_Description.Text = dr["Level_Description"].ToString();
                }


            }
            catch (HRMSException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }


        }

        private void dg_AdminLevel_Details_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        //Admin Speciality
        private void btn_AdminSpeciality_Add_Click(object sender, RoutedEventArgs e)
        {



        }

        private void btn_AdminSpeciality_Display_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btn_AdminSpeciality_Delete_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btn_AdminSpeciality_Update_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btn_AdminSpeciality_Reset_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btn_AdminSpeciality_Search_Click(object sender, RoutedEventArgs e)
        {

        }

        private void dg_AdminSpeciality_Details_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void TabControl_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            // txt_EmpId.Text = EmployeeValidation.GetAutoGeneratedId_BLL().ToString();

            // textBox_AdminSpeciality_ID.Text=Speciality
            //  textBox_AdminUsers_ID.Text=UserValidation.get
            textBox_Admin_CivilStatus_ID.Text = CivilStatus_BL.GetAutogeneratedCivilStatusID_BL().ToString();
            textBox_AdminUsers_ID.Text = UserValidation.AutoGenUserId_BL().ToString();
            DataTable dtRole = UserValidation.LoadUserRoles_BLL();
            if (dtRole.Rows.Count >= 0)
            {
                cmb_role.ItemsSource = dtRole.DefaultView;

                cmb_role.DisplayMemberPath = "Role_Name";
                cmb_role.SelectedValuePath = "Role_Id";

            }
        }

        private void TabItem_Loaded(object sender, RoutedEventArgs e)
        {
            textBox_AdminLevel_ID.Text = Level_BL.GetAutogeneratedLevelID_BL().ToString();
        }
    }
}
