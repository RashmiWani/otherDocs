﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace HRMS
{
    /// <summary>
    /// Interaction logic for HRClerkDatabase.xaml
    /// </summary>
    public partial class HRClerkDatabase : Window
    {
        public HRClerkDatabase()
        {
            InitializeComponent();
        }

        //User Employee
        private void btn_Employee_Add_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btn_Employee_Update_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btn_Employee_Delete_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btn_Employee_Display_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btn_Employee_Reset_Click(object sender, RoutedEventArgs e)
        {
            textBox_Employee_Firstname.Clear();
            textBox_Employee_Middlename.Clear();
            textBox_Employee_Lastname.Clear();
            //dtpkr_Employee_DOB.ClearValue();
            textBox_Employee_Age.Clear();
            //rdb_Employee_Male.ClearValue();
            //rdb_Employee_Female.ClearValue();
            //cmb_Employee_CivilStatus.ClearValue();
            textBox_Employee_Religion.Clear();
            textBox_Employee_Citizenship.Clear();
            textBox_Employee_MobilNumber.Clear();
            textBox_Employee_HomePhoneNumber.Clear();
            textBox_Employee_Address.Clear();
            textBox_Employee_City.Clear();
            textBox_Employee_State.Clear();
            textBox_Employee_Pincode.Clear();
            textBox_Employee_Country.Clear();
            //cmb_Employee_ProjectID.ClearValue();
            //cmb_Employee_SkillID.ClearValue();
            textBox_Employee_EduBg.Clear();
            textBox_Employee_EmailID.Clear();
            //cmb_Employee_LevelID.ClearValue();
            //dtpkr_Employee_DateHired.ClearValue();
            //cmb_Employee_Speciality.ClearValue();
            //cmb_Employee_Status.ClearValue();
        }

        private void btn_Employee_Search_Click(object sender, RoutedEventArgs e)
        {

        }

        private void dg_Employee_Details_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        //User Project
        private void btn_Project_Add_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btn_Project_Display_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btn_Project_Delete_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btn_Project_Update_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btn_Project_Reset_Click(object sender, RoutedEventArgs e)
        {
            textBox_Project_ID.Clear();
            textBox_Project_Name.Clear();
            textBox_Project_Description.Clear();
            textBox_Project_Client.Clear();
            //dtpkr_Project_StartDate.ClearValue();
            //dtpkr_Project_EndDate.ClearValue();
        }

        private void btn_Project_Search_Click(object sender, RoutedEventArgs e)
        {

        }

        private void dg_UserProject_Details_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        //User Category
        private void btn_Category_Add_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btn_Category_Display_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btn_Category_Delete_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btn_Category_Update_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btn_Category_Reset_Click(object sender, RoutedEventArgs e)
        {
            textBox_Category_ID.Clear();
            textBox_Category_Name.Clear();
            textBox_Category_Description.Clear();
        }

        private void btn_Category_Search_Click(object sender, RoutedEventArgs e)
        {

        }

        private void dg_Category_Details_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        //User Skills
        private void btn_Skill_Add_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btn_Skill_Display_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btn_Skill_Delete_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btn_Skill_Update_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btn_Skill_Reset_Click(object sender, RoutedEventArgs e)
        {
            textBox_Skill_ID.Clear();
            textBox_Skill_Name.Clear();
            textBox_Skill_Description.Clear();
        }

        private void btn_Skill_Search_Click(object sender, RoutedEventArgs e)
        {

        }

        private void dg_Skill_Details_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

    }
}
