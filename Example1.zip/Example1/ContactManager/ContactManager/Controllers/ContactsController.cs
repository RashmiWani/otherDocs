﻿using ContactManager.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace ContactManager.Controllers
{
    //Contacts Controller :- this class will perform action based on http verbs
    public class ContactsController : ApiController
    {
        Contact[] contacts = new Contact[] 
        {
            new Contact
       {
            ContactId=101,
           Name = "Debra Garcia",
           Address = "1234 Main St",
           City = "Redmond",
           State = "WA",
           Zip = "10999",
           Email = "debra@example.com",
          
       },
        new Contact
        {
            ContactId=102,
            Name = "Thorsten Weinrich",
            Address = "5678 1st Ave W",
            City = "Redmond",
            State = "WA",
            Zip = "10999",
            Email = "thorsten@example.com",
           
        },
        new Contact
        {
            ContactId=103,
            Name = "Yuhong Li",
            Address = "9012 State st",
            City = "Redmond",
            State = "WA",
            Zip = "10999",
            Email = "yuhong@example.com",
           
        },
        new Contact
        {
            ContactId=104,
            Name = "Jon Orton",
            Address = "3456 Maple St",
            City = "Redmond",
            State = "WA",
            Zip = "10999",
            Email = "jon@example.com",
            
        },
        new Contact
        {
            Name = "Diliana Alexieva-Bosseva",
            Address = "7890 2nd Ave E",
            City = "Redmond",
            State = "WA",
            Zip = "10999",
            Email = "diliana@example.com",
            
        }
        };

        //This Method will return all the contacts in contact array
        public IEnumerable<Contact> Get()
        {
            return contacts;
        }

        //This Method will return the contact based on contact id supplied
        public IHttpActionResult Get(int id)
        {
            var contact = contacts.FirstOrDefault((c) => c.ContactId == id);

            if (contact == null)
            {
                return NotFound();
            }

            return Ok(contact);
        }
    }
}
