﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Http; //Namespace for using HttpClient Class
using System.Net.Http.Headers;
using Newtonsoft.Json; //Namespace for using JsonConvert Class . To Added using NuGetPackage Manager

namespace ContactManagerDesktopClient
{
    public partial class Form1 : Form
    {
        HttpClient client;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            GetAllContacts();
        }

        //Method for retrieving all the contact from web api 
        protected  async void GetAllContacts()
        {
            using (client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:64937/");
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                HttpResponseMessage response = await client.GetAsync("api/contacts");

                if(response.IsSuccessStatusCode)
                {
                    string contacts = await response.Content.ReadAsStringAsync();

                    List<Contact> clist = JsonConvert.DeserializeObject<List<Contact>>(contacts);

                    MessageBox.Show(contacts);

                    dataGridView1.DataSource = clist.ToList();
                }
            }
        }

        //Method for retireving contact based on id provided
        protected async void GetAllContacts(int id)
        {
            using (client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:64937/");
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                HttpResponseMessage response = await client.GetAsync("api/contacts/"+id);

                if (response.IsSuccessStatusCode)
                {
                    string contacts = await response.Content.ReadAsStringAsync();

                    //List<Contact> clist = JsonConvert.DeserializeObject<List<Contact>>(contacts);

                    //MessageBox.Show(contacts);
                    Contact c = JsonConvert.DeserializeObject<Contact>(contacts);

                    //dataGridView1.DataSource = clist.ToList();
                    if (c != null)
                    {
                        txtName.Text = c.Name;
                        txtAddress.Text = c.Address;
                        txtCity.Text = c.City;
                        txtState.Text = c.State;
                        txtZip.Text = c.Zip;
                        txtEmail.Text = c.Email;
                    }
                    else
                    {
                        MessageBox.Show("Contacts not available");
                    }
                }
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            GetAllContacts(Convert.ToInt32(txtContactID.Text));
        }
    }

    public class Contact
    {
        public int ContactId { get; set; }
        public string Name { get; set; }
        public string Address { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string Zip { get; set; }
        public string Email { get; set; }
    }
}
